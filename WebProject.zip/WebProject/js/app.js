const text = "At Skill Hub, every skill you learn is a step towards a better tomorrow. Growth and progress never stop!";
const typingText = document.getElementById('typing-text');
let index = 0;

function typeWriter() {
  if (index < text.length) {
    typingText.innerHTML += text.charAt(index);
    index++;
    setTimeout(typeWriter, 100);
  }
}

window.onload = typeWriter;
document.querySelector('.filter-btn').addEventListener('click', function () {
  const category = document.getElementById('category').value;
  const difficulty = document.getElementById('difficulty').value;
  const popularity = document.getElementById('popularity').value;

  const courseCards = document.querySelectorAll('.course-card');

  courseCards.forEach(card => {
    const cardCategory = card.getAttribute('data-category');
    const cardDifficulty = card.getAttribute('data-difficulty');

    let categoryMatch = (category === 'all' || cardCategory === category);
    let difficultyMatch = (difficulty === 'all' || cardDifficulty === difficulty);

    let popularityMatch = true;

    if (categoryMatch && difficultyMatch && popularityMatch) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
});

function enroll() {
  window.location.href = 'courses.html';
}


lucide.createIcons();
document.getElementById('logout-btn').addEventListener('click', function () {

  alert('You have successfully logged out!');
  window.location.href = 'login.html';
});

document.getElementById('profile-btn').addEventListener('click', function () {
  window.location.href = 'profile.html';
});

document.addEventListener('DOMContentLoaded', function () {
  const savedMode = localStorage.getItem('mode');

  if (savedMode) {
    document.body.classList.add(savedMode);
    if (savedMode === 'dark-mode') {
      document.getElementById('mode-icon').setAttribute('data-lucide', 'moon');
    } else {
      document.getElementById('mode-icon').setAttribute('data-lucide', 'sun');
    }
  }
});

document.getElementById('mode-toggle-btn').addEventListener('click', () => {
  if (document.body.classList.contains('light-mode')) {
    document.body.classList.remove('light-mode');
    document.body.classList.add('dark-mode');
    localStorage.setItem('mode', 'dark-mode');
    document.getElementById('mode-icon').setAttribute('data-lucide', 'moon');
  } else {
    document.body.classList.remove('dark-mode');
    document.body.classList.add('light-mode');
    localStorage.setItem('mode', 'light-mode');
    document.getElementById('mode-icon').setAttribute('data-lucide', 'sun');
  }

  lucide.createIcons();
});
